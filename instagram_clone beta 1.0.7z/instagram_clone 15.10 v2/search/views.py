from django.shortcuts import render
from django.contrib.auth import get_user_model
from django.db.models import Q
from posts.models import Post

def search(request):
    query = request.GET.get('q')
    users = []
    posts = []

    if query:
        users = get_user_model().objects.filter(
            Q(username__icontains=query) | Q(email__icontains=query)
        )
        posts = Post.objects.filter(
            Q(caption__icontains=query) | Q(user__username__icontains=query)
        )
        
    return render(request, 'search/search_results.html', {'query': query, 'users': users, 'posts': posts})