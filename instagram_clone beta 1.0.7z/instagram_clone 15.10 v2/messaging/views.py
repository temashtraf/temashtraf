from django.http import HttpResponse

def messaging_view(request):
    return HttpResponse("Добро пожаловать в раздел сообщений!")