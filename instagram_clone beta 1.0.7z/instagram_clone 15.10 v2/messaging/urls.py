from django.urls import path
from . import views

urlpatterns = [
    path('', views.messaging_view, name='messaging_home'),
]