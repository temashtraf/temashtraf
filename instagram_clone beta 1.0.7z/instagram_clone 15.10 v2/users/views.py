from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from .forms import UserRegistrationForm
from django.contrib.auth.views import LoginView, LogoutView
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required
from .forms import EditProfileForm
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser
from posts.models import Post
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import Profile
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model

User = get_user_model()

@login_required
def follow_toggle(request):
    if request.method == "POST":
        user_id = request.POST.get('user_id')
        target_user = User.objects.get(id=user_id)
        profile = request.user.profile  # текущий пользователь

        if target_user.profile in profile.following.all():
            profile.following.remove(target_user.profile)
            following = False
        else:
            profile.following.add(target_user.profile)
            following = True

        return JsonResponse({
            "following": following,
            "followers_count": target_user.profile.followers.count
        })

class UserRegistrationForm(UserCreationForm):
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'password1', 'password2']

class CustomLoginView(LoginView):
    template_name = 'users/login.html'

class CustomLogoutView(LogoutView):
    next_page = reverse_lazy('login')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('post_list')
    else:
        form = UserRegistrationForm()
    return render(request, 'users/register.html', {'form': form})

def profile(request):
    posts = Post.objects.filter(user=request.user)
    return render(request, 'users/profile.html', {'user': request.user, 'posts': posts})

def edit_profile(request):
    if request.method == 'POST':
        form = EditProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = EditProfileForm(instance=request.user)
    return render(request, 'users/edit_profile.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('post_list')