from django.urls import path
from . import views
from django.contrib.auth.views import LoginView

urlpatterns = [
    path('profile/', views.profile, name='profile'),
    path('register/', views.register, name='register'),
    path('edit/', views.edit_profile, name='edit_profile'),
    path('logout/', views.logout_view, name='logout'),
    path('login/', LoginView.as_view(template_name='users/login.html'), name='login'),
    path('follow-toggle/', views.follow_toggle, name='follow_toggle'),
]
