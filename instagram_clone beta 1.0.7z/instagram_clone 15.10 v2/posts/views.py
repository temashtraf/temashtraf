from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Post, Comment
from .forms import PostForm
from django.contrib.auth.views import LoginView
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import JsonResponse
import json
from .forms import CommentForm
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt

@login_required
@csrf_exempt
def add_comment(request):
    if request.method == "POST":
        data = json.loads(request.body)
        post = Post.objects.get(id=data["post_id"])
        comment = Comment.objects.create(
            post=post,
            user=request.user,
            content=data["content"]
        )
        return JsonResponse({"success": True, "username": request.user.username, "content": comment.content})
    return JsonResponse({"success": False}, status=400)

@login_required
def profile(request):
    return render(request, 'profile.html')

def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        User.objects.create_user(username=username, password=password)
        messages.success(request, 'Account created successfully!')
        return redirect('login')
    return render(request, 'register.html')

class CustomLoginView(LoginView):
    template_name = 'login.html'

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def post_list(request):
    posts = Post.objects.all().order_by('-created_at')
    return render(request, 'posts/post_list.html', {'posts': posts})

@login_required
def post_create(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.user = request.user
            post.save()
            return redirect('post_list')
    else:
        form = PostForm()
    return render(request, 'posts/post_form.html', {'form': form})

@login_required
def post_detail(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    return render(request, 'posts/post_detail.html', {'post': post})

def like_post(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        post_id = data.get('post_id')
        post = Post.objects.get(id=post_id)
        
        if request.user in post.likes.all():
            post.likes.remove(request.user)
            liked = False
        else:
            post.likes.add(request.user)
            liked = True
        
        return JsonResponse({'liked': liked, 'likes_count': post.likes.count()})
    return JsonResponse({'error': 'Invalid request'}, status=400)

def post_list(request):
    posts = Post.objects.all().prefetch_related('likes')

    for post in posts:
        post.liked_by_user = request.user.is_authenticated and request.user in post.likes.all()

    return render(request, 'posts/post_list.html', {'posts': posts})

